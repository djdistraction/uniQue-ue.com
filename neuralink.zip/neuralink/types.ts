// Added React import to fix the "Cannot find namespace 'React'" error on line 5
import React from 'react';

export interface SectionProps {
  id: string;
  title: string;
  children: React.ReactNode;
}

export interface TableRow {
  feature: string;
  characteristics: string;
  capability: string;
}

export interface MappingRow {
  stage: string;
  mapping: string;
  function: string;
}