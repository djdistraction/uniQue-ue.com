
import React from 'react';
import { SectionProps } from '../types';

export const Section: React.FC<SectionProps> = ({ id, title, children }) => {
  return (
    <section id={id} className="py-20 border-b border-slate-100 last:border-0 page-break">
      <h2 className="text-3xl font-bold text-slate-900 mb-8 flex items-center gap-4">
        <span className="w-1 h-10 bg-blue-600 rounded-full"></span>
        {title}
      </h2>
      <div className="prose prose-slate max-w-none">
        {children}
      </div>
    </section>
  );
};
