
import React from 'react';

interface SidebarProps {
  activeSection: string;
  onPrint: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeSection, onPrint }) => {
  const navItems = [
    { id: 'cover', label: 'Cover' },
    { id: 'summary', label: 'Executive Summary' },
    { id: 'technical', label: 'Technical Alignment' },
    { id: 'architecture', label: 'Proposed Architecture' },
    { id: 'applications', label: 'Applications & Impact' },
    { id: 'recommendation', label: 'Next Steps' },
  ];

  return (
    <div className="flex flex-col h-full p-8">
      <div className="mb-10 flex items-center gap-3">
        <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white font-black text-xl">N</div>
        <div className="font-bold text-slate-800 tracking-tight leading-tight">
          NEURALINK<br/><span className="text-xs text-blue-600 uppercase tracking-widest font-black">X MIDI 2.0</span>
        </div>
      </div>

      <nav className="flex-1 space-y-2">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6 px-4">Navigation</h3>
        {navItems.map((item) => (
          <a
            key={item.id}
            href={`#${item.id}`}
            className={`block px-4 py-3 rounded-lg text-sm font-medium transition-all ${
              activeSection === item.id 
                ? 'bg-blue-50 text-blue-700 shadow-sm border-l-4 border-blue-600' 
                : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            {item.label}
          </a>
        ))}
      </nav>

      <div className="mt-auto pt-8 border-t border-slate-100">
        <button 
          onClick={onPrint}
          className="w-full flex items-center justify-center gap-2 bg-slate-900 text-white py-3 rounded-xl font-bold hover:bg-blue-600 transition-colors shadow-lg"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          Export Proposal
        </button>
        <p className="text-[10px] text-slate-400 mt-4 text-center uppercase tracking-widest">Randall Butler © 2026</p>
      </div>
    </div>
  );
};
