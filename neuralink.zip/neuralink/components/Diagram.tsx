
import React from 'react';

export const Diagram: React.FC = () => {
  return (
    <div className="w-full py-12 px-8 bg-slate-50 rounded-3xl border border-slate-100 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 rounded-full -mr-32 -mt-32"></div>
      
      <div className="relative flex flex-col md:flex-row items-center justify-between gap-8 max-w-4xl mx-auto">
        {/* Input */}
        <div className="flex flex-col items-center gap-3">
          <div className="w-20 h-20 rounded-full bg-white border-2 border-blue-600 flex items-center justify-center shadow-lg relative">
             <div className="absolute inset-0 rounded-full border border-blue-200 animate-ping opacity-25"></div>
             <svg className="w-10 h-10 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
             </svg>
          </div>
          <span className="text-xs font-bold text-slate-900 tracking-widest uppercase">N1 Implant</span>
          <span className="text-[10px] text-slate-400 text-center">LFPs & Spikes</span>
        </div>

        {/* Arrow */}
        <div className="flex-1 h-[2px] bg-slate-200 hidden md:block relative">
          <div className="absolute top-1/2 right-0 -translate-y-1/2 w-2 h-2 border-t-2 border-r-2 border-slate-300 transform rotate-45"></div>
        </div>

        {/* Decoder */}
        <div className="flex flex-col items-center gap-3">
          <div className="px-6 py-4 rounded-xl bg-slate-900 text-white shadow-xl border border-slate-700">
             <div className="flex gap-1 mb-2">
                <div className="w-1 h-3 bg-blue-400 animate-pulse"></div>
                <div className="w-1 h-5 bg-blue-500 animate-pulse delay-75"></div>
                <div className="w-1 h-2 bg-blue-300 animate-pulse delay-150"></div>
                <div className="w-1 h-4 bg-blue-400 animate-pulse delay-100"></div>
             </div>
             <span className="text-xs font-mono">Neural Decoder</span>
          </div>
          <span className="text-[10px] text-slate-400 text-center uppercase tracking-tighter">Inference ASIC</span>
        </div>

        {/* Arrow */}
        <div className="flex-1 h-[2px] bg-slate-200 hidden md:block relative">
          <div className="absolute top-1/2 right-0 -translate-y-1/2 w-2 h-2 border-t-2 border-r-2 border-slate-300 transform rotate-45"></div>
        </div>

        {/* MIDI Layer */}
        <div className="flex flex-col items-center gap-3">
          <div className="px-8 py-6 rounded-2xl bg-blue-600 text-white shadow-2xl relative">
             <div className="absolute -top-2 -right-2 bg-yellow-400 text-slate-900 text-[8px] font-black px-1.5 py-0.5 rounded shadow">MIDI 2.0</div>
             <span className="text-sm font-bold uppercase tracking-widest">UMP Translation</span>
          </div>
          <span className="text-[10px] text-slate-400 text-center uppercase">32-bit Mapping</span>
        </div>

        {/* Arrow */}
        <div className="flex-1 h-[2px] bg-slate-200 hidden md:block relative">
          <div className="absolute top-1/2 right-0 -translate-y-1/2 w-2 h-2 border-t-2 border-r-2 border-slate-300 transform rotate-45"></div>
        </div>

        {/* Output */}
        <div className="flex flex-col items-center gap-3">
          <div className="grid grid-cols-2 gap-2">
            <div className="w-10 h-10 rounded bg-white shadow flex items-center justify-center border border-slate-100" title="Prosthetics">
              <svg className="w-6 h-6 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
              </svg>
            </div>
            <div className="w-10 h-10 rounded bg-white shadow flex items-center justify-center border border-slate-100" title="DAW">
              <svg className="w-6 h-6 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
              </svg>
            </div>
          </div>
          <span className="text-[10px] text-slate-400 text-center font-bold uppercase">Actuation Layer</span>
        </div>
      </div>
      
      <div className="mt-8 text-center">
         <p className="text-xs text-slate-400 italic">Figure 1: High-level overview of the proposed Neural-to-MIDI Universal Actuation Protocol.</p>
      </div>
    </div>
  );
};
