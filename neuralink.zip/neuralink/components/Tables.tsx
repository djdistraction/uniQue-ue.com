
import React from 'react';
import { TableRow, MappingRow } from '../types';

export const ComparisonTable: React.FC<{ data: TableRow[] }> = ({ data }) => {
  return (
    <div className="overflow-x-auto rounded-xl border border-slate-200">
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="bg-slate-50 border-b border-slate-200">
            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Feature</th>
            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Neural Characteristic</th>
            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">MIDI 2.0 Capability</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row, i) => (
            <tr key={i} className="border-b border-slate-100 last:border-0 hover:bg-slate-50 transition-colors">
              <td className="px-6 py-5 font-bold text-slate-900 align-top">{row.feature}</td>
              <td className="px-6 py-5 text-slate-600 text-sm leading-relaxed align-top">{row.characteristics}</td>
              <td className="px-6 py-5 text-blue-700 text-sm leading-relaxed align-top bg-blue-50/30">{row.capability}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export const MappingTable: React.FC<{ data: MappingRow[]; isDark?: boolean }> = ({ data, isDark = false }) => {
  const textColor = isDark ? 'text-slate-300' : 'text-slate-600';
  const headingColor = isDark ? 'text-slate-400' : 'text-slate-500';
  const mainColor = isDark ? 'text-white' : 'text-slate-900';
  const borderColor = isDark ? 'border-slate-800' : 'border-slate-200';

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className={`border-b-2 ${borderColor}`}>
            <th className={`px-4 py-3 text-xs font-bold ${headingColor} uppercase tracking-widest`}>Neuralink Stage</th>
            <th className={`px-4 py-3 text-xs font-bold ${headingColor} uppercase tracking-widest`}>MIDI 2.0 Mapping</th>
            <th className={`px-4 py-3 text-xs font-bold ${headingColor} uppercase tracking-widest`}>Function</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row, i) => (
            <tr key={i} className={`border-b ${borderColor} last:border-0`}>
              <td className={`px-4 py-4 font-semibold ${mainColor}`}>{row.stage}</td>
              <td className="px-4 py-4">
                <code className={`px-2 py-1 rounded bg-blue-500/10 text-blue-400 font-mono text-sm`}>{row.mapping}</code>
              </td>
              <td className={`px-4 py-4 text-sm ${textColor}`}>{row.function}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
