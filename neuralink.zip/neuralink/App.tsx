
import React, { useState, useEffect } from 'react';
import { PROPOSAL_METADATA, ALIGNMENT_DATA, MAPPING_DATA } from './constants';
import { Section } from './components/Section';
import { ComparisonTable, MappingTable } from './components/Tables';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Diagram } from './components/Diagram';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState('cover');

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['cover', 'summary', 'technical', 'architecture', 'applications', 'recommendation'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element && scrollPosition >= element.offsetTop && scrollPosition < element.offsetTop + element.offsetHeight) {
          setActiveSection(section);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50">
      {/* Sidebar - Desktop Only */}
      <div className="hidden md:block w-72 h-screen sticky top-0 bg-white border-r border-slate-200 z-10 no-print">
        <Sidebar activeSection={activeSection} onPrint={handlePrint} />
      </div>

      {/* Main Content */}
      <main className="flex-1 max-w-5xl mx-auto px-6 py-12 md:px-12 md:py-20 bg-white shadow-xl min-h-screen">
        
        {/* Cover Page Section */}
        <section id="cover" className="min-h-[80vh] flex flex-col justify-center border-b border-slate-100 pb-20 mb-20 page-break">
          <div className="mb-12">
            <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold tracking-widest uppercase rounded mb-4">
              Innovation Proposal v1.2
            </span>
            <h1 className="text-5xl md:text-6xl font-extrabold text-slate-900 leading-tight mb-4">
              {PROPOSAL_METADATA.title}
            </h1>
            <p className="text-xl md:text-2xl text-slate-600 font-light max-w-3xl leading-relaxed">
              {PROPOSAL_METADATA.subtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mt-12 border-t border-slate-100 pt-12">
            <div>
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Prepared By</h3>
              <p className="text-lg font-semibold text-slate-800">{PROPOSAL_METADATA.author}</p>
              <p className="text-slate-600">{PROPOSAL_METADATA.contact.role}</p>
              <p className="text-slate-500 mt-2 text-sm">
                {PROPOSAL_METADATA.contact.location}<br />
                {PROPOSAL_METADATA.contact.email}<br />
                {PROPOSAL_METADATA.contact.phone}
              </p>
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Submission Details</h3>
              <p className="text-slate-600">
                <span className="font-semibold text-slate-800">Date:</span> {PROPOSAL_METADATA.date}<br />
                <span className="font-semibold text-slate-800">Recipient:</span> {PROPOSAL_METADATA.recipient}
              </p>
            </div>
          </div>
        </section>

        {/* Executive Summary */}
        <Section id="summary" title="Executive Summary">
          <p className="text-lg text-slate-700 leading-relaxed mb-6">
            Current Brain-Computer Interfaces (BCIs) excel in neural recording but suffer from fragmented output: connecting to prosthetics, cursors, wheelchairs, or creative tools requires custom drivers for each device ("Driver Hell").
          </p>
          <p className="text-lg text-slate-700 leading-relaxed mb-8">
            This proposal recommends adopting <strong>MIDI 2.0</strong> (matured by 2026 with 32-bit resolution, Jitter Reduction Timestamps, bidirectional MIDI Capability Inquiry [MIDI-CI], and Universal MIDI Packets [UMP]) as Neuralink's standardized "Actuation Layer." Mapping decoded neural intention vectors to MIDI 2.0 enables plug-and-play interoperability with millions of existing robotics, IoT, industrial, and creative hardware—shifting focus from bespoke drivers to profile definitions.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
            <div className="bg-slate-50 p-6 rounded-xl border border-slate-100">
              <h4 className="font-bold text-blue-700 mb-2">High-Fidelity Transmission</h4>
              <p className="text-sm text-slate-600">Matches N1's 10-bit neural data with 32-bit resolution, far beyond MIDI 1.0's 7-bit quantization.</p>
            </div>
            <div className="bg-slate-50 p-6 rounded-xl border border-slate-100">
              <h4 className="font-bold text-blue-700 mb-2">Bidirectional Feedback</h4>
              <p className="text-sm text-slate-600">Allows devices to send state data back (e.g., robotic pressure → somatosensory stimulation).</p>
            </div>
            <div className="bg-slate-50 p-6 rounded-xl border border-slate-100">
              <h4 className="font-bold text-blue-700 mb-2">Reduced Jitter</h4>
              <p className="text-sm text-slate-600">Ensures smooth motor control via specialized Jitter Reduction Timestamps.</p>
            </div>
            <div className="bg-slate-50 p-6 rounded-xl border border-slate-100">
              <h4 className="font-bold text-blue-700 mb-2">Semantic Compression</h4>
              <p className="text-sm text-slate-600">Reduces bandwidth from Mbps to Kbps for vision applications like Blindsight.</p>
            </div>
          </div>
        </Section>

        {/* Technical Alignment */}
        <Section id="technical" title="Technical Alignment: Why MIDI 2.0 Fits Neuralink">
          <p className="text-slate-700 mb-8">
            MIDI 2.0 addresses BCI constraints perfectly by providing a scalable, bidirectional, and highly granular data protocol that mirrors the complexity of human neural signatures.
          </p>
          <ComparisonTable data={ALIGNMENT_DATA} />
        </Section>

        {/* Proposed Architecture */}
        <Section id="architecture" title="Proposed Architecture">
          <div className="my-10">
            <Diagram />
          </div>
          
          <div className="space-y-6">
            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold flex-shrink-0">1</div>
              <div>
                <h4 className="font-bold text-slate-800">Input Layer</h4>
                <p className="text-slate-600">N1 electrode array records Local Field Potentials (LFPs) & spikes from primary motor/sensory areas.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold flex-shrink-0">2</div>
              <div>
                <h4 className="font-bold text-slate-800">Neural Decoder</h4>
                <p className="text-slate-600">On-chip ASIC aggregates spikes into velocity/intention vectors using machine learning inference.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold flex-shrink-0">3</div>
              <div>
                <h4 className="font-bold text-slate-800">MIDI Translation Layer</h4>
                <p className="text-slate-600">Core Proposal: Mapping continuous/discrete intentions into Universal MIDI Packets (UMP).</p>
              </div>
            </div>
          </div>

          <div className="mt-12 bg-slate-900 rounded-2xl p-8 text-white shadow-2xl">
            <h4 className="text-xl font-bold mb-6 flex items-center gap-2">
              <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></span>
              Neural-to-MIDI Mapping Strategy
            </h4>
            <MappingTable data={MAPPING_DATA} isDark={true} />
          </div>
        </Section>

        {/* Applications & Impact */}
        <Section id="applications" title="Applications & Impact">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="border border-slate-200 p-8 rounded-2xl hover:border-blue-300 transition-colors">
              <h4 className="text-xl font-bold text-slate-900 mb-4">Creative Agency</h4>
              <p className="text-slate-600 text-sm leading-relaxed">
                Direct mind-to-MIDI interface with DAWs (Ableton, Logic), effects processors, and lighting. Paralyzed musicians could compose and perform immersive shows, restoring irreplaceable creative expression.
              </p>
            </div>
            <div className="border border-slate-200 p-8 rounded-2xl hover:border-blue-300 transition-colors">
              <h4 className="text-xl font-bold text-slate-900 mb-4">Advanced Robotics</h4>
              <p className="text-slate-600 text-sm leading-relaxed">
                Direct servo control (Dynamixel smart servos). Proprioception loops: Robotic hand sends pressure data back as MIDI → N1 stimulates somatosensory cortex.
              </p>
            </div>
            <div className="border border-slate-200 p-8 rounded-2xl hover:border-blue-300 transition-colors">
              <h4 className="text-xl font-bold text-slate-900 mb-4">IoT Integration</h4>
              <p className="text-slate-600 text-sm leading-relaxed">
                Map neural states (anxiety/relaxation) to smart home elements (DMX/Hue lighting, HVAC) via MIDI-to-IoT bridges.
              </p>
            </div>
            <div className="border border-slate-200 p-8 rounded-2xl hover:border-blue-300 transition-colors">
              <h4 className="text-xl font-bold text-slate-900 mb-4">Blindsight Compression</h4>
              <p className="text-slate-600 text-sm leading-relaxed">
                Semantic compression: External camera encodes objects as MIDI events (Pitch = vertical, Pan = horizontal). Reduces data from ~10 Mbps to Kbps.
              </p>
            </div>
          </div>
        </Section>

        {/* Recommendation */}
        <Section id="recommendation" title="Recommendation & Next Steps">
          <div className="bg-blue-50 border-l-4 border-blue-600 p-8 rounded-r-2xl mb-12">
            <p className="text-blue-900 text-lg leading-relaxed font-medium">
              Neuralink should establish a working group with the MIDI Association to define a standardized "Neuro-Control Profile" within MIDI 2.0. This enables third-party "Neuralink-Ready" hardware via the open standard.
            </p>
          </div>
          
          <p className="text-slate-700 mb-12">
            I am available to contribute my music technology and production expertise—perhaps in profile development, creative application testing, or integration roles. I welcome discussion, feedback, or collaboration to refine this further.
          </p>

          <div className="border-t border-slate-200 pt-12 text-center md:text-left">
            <p className="text-slate-500 mb-2 italic">Thank you for considering this proposal.</p>
            <p className="text-2xl font-bold text-slate-900">Randall Butler</p>
            <p className="text-slate-500">Houston, TX • January 21, 2026</p>
          </div>
        </Section>
      </main>

      {/* Footer / Floating Actions */}
      <div className="fixed bottom-6 right-6 flex flex-col gap-3 no-print">
        <button 
          onClick={handlePrint}
          className="bg-slate-900 text-white p-4 rounded-full shadow-2xl hover:bg-slate-800 transition-all transform hover:scale-110 flex items-center justify-center"
          title="Download PDF"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default App;
