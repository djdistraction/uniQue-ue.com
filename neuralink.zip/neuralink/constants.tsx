
import { TableRow, MappingRow } from './types';

export const PROPOSAL_METADATA = {
  title: "MIDI 2.0 Proposal for Neuralink",
  subtitle: "Universal Neuro-Actuation Protocol: Solving Interoperability, Bandwidth, and Creative Agency Challenges",
  author: "Randall Butler",
  date: "January 21, 2026",
  recipient: "Neuralink Engineering & Careers Team",
  contact: {
    location: "Houston, TX",
    phone: "409-354-2535",
    email: "randall.gene.tx@gmail.com",
    role: "Multi-instrumentalist, Vocalist, DJ, Stage Lighting/Special Effects Designer"
  }
};

export const ALIGNMENT_DATA: TableRow[] = [
  {
    feature: "Resolution",
    characteristics: "Continuous, nuanced analog spikes (10-bit digitization on N1 ASIC)",
    capability: "32-bit resolution (>4 billion steps per controller) – lossless transmission of intention vectors, no 'stair-stepping' artifacts."
  },
  {
    feature: "Latency/Timing",
    characteristics: "Sub-millisecond spike timing critical for motor control",
    capability: "Jitter Reduction Timestamps (via UMP) – embed sender time; receiver executes precisely, smoothing wireless/Bluetooth jitter."
  },
  {
    feature: "Data Flow",
    characteristics: "Brain expects sensory feedback (proprioception)",
    capability: "Bidirectional communication – devices send state data back to BCI (e.g., grip pressure as MIDI message)."
  },
  {
    feature: "Configuration",
    characteristics: "Neural plasticity requires dynamic re-mapping",
    capability: "MIDI-CI Profile Configuration – auto-queries device ('Are you a wheelchair? Synth? Drone?'), auto-maps outputs."
  }
];

export const MAPPING_DATA: MappingRow[] = [
  {
    stage: "Discovery",
    mapping: "MIDI-CI",
    function: "BCI queries device profile (e.g., wheelchair, cursor, synth)."
  },
  {
    stage: "Intention (Continuous)",
    mapping: "32-bit Control Change",
    function: "Neural vectors mapped to registered controllers."
  },
  {
    stage: "Intention (Discrete)",
    mapping: "Note On/Note Off",
    function: "Selections/clicks with velocity nuance."
  },
  {
    stage: "Drift Correction",
    mapping: "Relative Controllers",
    function: "Compensates for neural drift without recalibration."
  }
];
